# TransacaoFinanceira - AWS Lambda (PostgreSQL)

Este pacote foi adaptado para rodar como AWS Lambda com persistência em PostgreSQL.

## Deploy
1. Instale dependências nativas (psycopg2-binary) em um ambiente compatível com AWS Lambda (Amazon Linux 2)
   ou utilize uma Lambda Layer que contenha `psycopg2` compilado para Lambda.
2. Configure as variáveis de ambiente na função Lambda:
   - PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD
3. Faça upload do ZIP deste repositório para a função Lambda.
   - Handler: `TransacaoFinanceira-refactore-python.lambda_function.lambda_handler`
4. Exemplos de payloads:
   - Obter saldo:
     { "action": "saldo", "conta_id": 1 }
   - Processar transação:
     { "action": "processar", "tipo": "saque", "valor": 100.0, "conta_origem": 1 }

Observação: este pacote NÃO inclui dependências nativas. Para deploy sem erro, empacote `psycopg2` compilado para Lambda.
