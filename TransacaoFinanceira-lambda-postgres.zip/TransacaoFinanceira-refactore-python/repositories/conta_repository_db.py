import os
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import Optional

class ContaRepositoryDB:
    """Repositório que usa PostgreSQL para persistência de contas e saldos.

    Configuração via variáveis de ambiente (exemplos):
        PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD

    Observação: este módulo depende de `psycopg2-binary`. Em AWS Lambda, prefira
    empacotar as dependências compatíveis com Amazon Linux 2 (camada ou container).
    """

    def __init__(self):
        self.host = os.environ.get('PG_HOST', 'localhost')
        self.port = int(os.environ.get('PG_PORT', 5432))
        self.database = os.environ.get('PG_DATABASE', 'transacoes')
        self.user = os.environ.get('PG_USER', 'postgres')
        self.password = os.environ.get('PG_PASSWORD', '')

    def _get_conn(self):
        return psycopg2.connect(
            host=self.host,
            port=self.port,
            database=self.database,
            user=self.user,
            password=self.password
        )

    def criar_tabela_se_nao_existe(self):
        sql = """
        CREATE TABLE IF NOT EXISTS contas (
            conta_id BIGINT PRIMARY KEY,
            saldo NUMERIC NOT NULL DEFAULT 0.0
        );
        """
        conn = self._get_conn()
        try:
            with conn:
                with conn.cursor() as cur:
                    cur.execute(sql)
        finally:
            conn.close()

    def obter_saldo(self, conta_id: int) -> float:
        """Retorna o saldo atual da conta. Se não existir, cria com saldo 0.0."""
        sql_select = "SELECT saldo FROM contas WHERE conta_id = %s;"
        sql_insert = "INSERT INTO contas (conta_id, saldo) VALUES (%s, %s);"
        conn = self._get_conn()
        try:
            with conn:
                with conn.cursor() as cur:
                    cur.execute(sql_select, (conta_id,))
                    row = cur.fetchone()
                    if row is None:
                        cur.execute(sql_insert, (conta_id, 0.0))
                        return 0.0
                    return float(row[0])
        finally:
            conn.close()

    def atualizar_saldo(self, conta_id: int, novo_saldo: float) -> None:
        """Atualiza o saldo de uma conta de forma atômica."""
        sql_upsert = "INSERT INTO contas (conta_id, saldo) VALUES (%s, %s) ON CONFLICT (conta_id) DO UPDATE SET saldo = EXCLUDED.saldo;"
        conn = self._get_conn()
        try:
            with conn:
                with conn.cursor() as cur:
                    cur.execute(sql_upsert, (conta_id, novo_saldo))
        finally:
            conn.close()

    def transferir(self, conta_origem: int, conta_destino: int, valor: float) -> None:
        """Realiza transferência deduzindo e adicionando saldo de forma transacional."""
        sql_select = "SELECT saldo FROM contas WHERE conta_id = %s FOR UPDATE;"
        sql_insert = "INSERT INTO contas (conta_id, saldo) VALUES (%s, %s) ON CONFLICT (conta_id) DO NOTHING;"
        conn = self._get_conn()
        try:
            with conn:
                with conn.cursor() as cur:
                    # garantir que ambas contas existam
                    cur.execute(sql_insert, (conta_origem, 0.0))
                    cur.execute(sql_insert, (conta_destino, 0.0))
                    # lock na linha de origem para concorrência
                    cur.execute(sql_select, (conta_origem,))
                    row = cur.fetchone()
                    saldo_origem = float(row[0]) if row else 0.0
                    if saldo_origem < valor:
                        raise ValueError('Saldo insuficiente na conta de origem.')
                    novo_origem = saldo_origem - valor
                    cur.execute("UPDATE contas SET saldo = %s WHERE conta_id = %s;", (novo_origem, conta_origem))
                    # creditar destino (pode ler sem lock isolado)
                    cur.execute("SELECT saldo FROM contas WHERE conta_id = %s;", (conta_destino,))
                    row2 = cur.fetchone()
                    saldo_destino = float(row2[0]) if row2 else 0.0
                    novo_destino = saldo_destino + valor
                    cur.execute("UPDATE contas SET saldo = %s WHERE conta_id = %s;", (novo_destino, conta_destino))
        finally:
            conn.close()
