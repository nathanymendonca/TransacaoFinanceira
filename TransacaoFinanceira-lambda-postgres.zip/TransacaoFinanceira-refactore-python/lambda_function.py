import os
import json
from models.transacao import Transacao
from services.transacao_service import TransacaoService
# preferir o repositório DB se disponível
try:
    from repositories.conta_repository_db import ContaRepositoryDB as ContaRepository
except Exception:
    from repositories.conta_repository import ContaRepository  # fallback in-memory

# Inicializar repositório e serviço fora do handler para reuso entre invocações
conta_repo = ContaRepository()
# Se o repositório oferecer criação de tabela, tentar criar
try:
    if hasattr(conta_repo, 'criar_tabela_se_nao_existe'):
        conta_repo.criar_tabela_se_nao_existe()
except Exception as e:
    # falha ignorada aqui; será reportada nas operações
    pass

service = TransacaoService(conta_repo)

def lambda_handler(event, context):
    """Ponto de entrada do AWS Lambda.

    Espera o `event` no formato JSON com chave 'action' que pode ser:
        - 'processar': processa uma transação. `payload` deve conter: tipo, valor, conta_origem, conta_destino (opcional)
        - 'saldo': obtém saldo de uma conta. `payload` deve conter: conta_id

    Retorna JSON com status e dados ou mensagem de erro.
    """
    try:
        body = event.get('body')
        if body and isinstance(body, str):
            body = json.loads(body)
        payload = event.get('payload') or body or event
        action = payload.get('action') or payload.get('type') or 'processar'

        if action == 'saldo':
            conta_id = int(payload.get('conta_id'))
            saldo = service.obter_saldo(conta_id)
            return { 'statusCode': 200, 'body': json.dumps({'status': 'sucesso', 'conta_id': conta_id, 'saldo': saldo}) }

        if action == 'processar':
            tipo = payload.get('tipo') or payload.get('type')
            valor = float(payload.get('valor'))
            conta_origem = payload.get('conta_origem') or payload.get('contaIdOrigem') or payload.get('contaId')
            conta_destino = payload.get('conta_destino') or payload.get('contaDestino')
            transacao = Transacao(tipo=tipo, valor=valor, conta_origem=conta_origem, conta_destino=conta_destino)
            service.processar(transacao)
            # retornar saldo da conta origem ou destino conforme contexto
            conta = transacao.conta_origem or transacao.conta_destino
            saldo = service.obter_saldo(int(conta))
            return { 'statusCode': 200, 'body': json.dumps({'status': 'sucesso', 'saldo': saldo}) }

        return { 'statusCode': 400, 'body': json.dumps({'status': 'erro', 'mensagem': 'Ação inválida'}) }
    except Exception as e:
        return { 'statusCode': 500, 'body': json.dumps({'status': 'erro', 'mensagem': str(e)}) }
